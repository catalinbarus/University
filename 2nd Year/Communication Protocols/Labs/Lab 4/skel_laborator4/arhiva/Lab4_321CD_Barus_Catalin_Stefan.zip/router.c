#include "skel.h"

int interfaces[ROUTER_NUM_INTERFACES];
struct route_table_entry *rtable;
int rtable_size;

struct arp_entry *arp_table;
int arp_table_len;

/*
 Returns a pointer (eg. &rtable[i]) to the best matching route
 for the given dest_ip. Or NULL if there is no matching route.
*/
struct route_table_entry *get_best_route(__u32 dest_ip) {
	/* TODO 1: Implement the function */

	/* Compar mastile din tabela de rutare pentru a obtine drumul cel mai bun*/
	uint32_t maxMASK = 0;
	struct route_table_entry *match;

	for (int i = 0; i < rtable_size; i++) {

		if ((rtable[i].mask & dest_ip) == rtable[i].prefix) {

			/* Masca cea mai mare reprezinta cel mai bun drum*/
			if (rtable[i].mask > maxMASK) {

				maxMASK = rtable[i].mask;
				match = &rtable[i];

			}
		}
	}


	/* Daca gasim o masca maxima, returnam intrarea din tabela de 
	rutare corespunzatoare*/
	if (maxMASK >= 0) {

		return match;
	}

	/*Altfel returnam NULL */
	return NULL;
}

/*
 Returns a pointer (eg. &arp_table[i]) to the best matching ARP entry.
 for the given dest_ip or NULL if there is no matching entry.
*/
struct arp_entry *get_arp_entry(__u32 ip) {
    /* TODO 2: Implement */

	/* Verificam daca ip-ul furnizat corespunde cu cel din tabela ARP si 
	returnam intrarea corespunzatoare din tabela */
    for (int i = 0; i < arp_table_len; i++) {

    	if (arp_table[i].ip == ip) {

    		return &arp_table[i];
    	}
	}

    return NULL;
}

int main(int argc, char *argv[])
{
	msg m;
	int rc;

	init();
	rtable = malloc(sizeof(struct route_table_entry) * 100);
	arp_table = malloc(sizeof(struct  arp_entry) * 100);
	DIE(rtable == NULL, "memory");
	rtable_size = read_rtable(rtable);
	parse_arp_table();
	/* Students will write code here */

	while (1) {

		rc = get_packet(&m);
		DIE(rc < 0, "get_message");
		struct ether_header *eth_hdr = (struct ether_header *)m.payload;
		struct iphdr *ip_hdr = (struct iphdr *)(m.payload + sizeof(struct ether_header));

		/* TODO 3: Check the checksum */


		/* Calculez si verific daca checksum-ul este valid cu cel din structura
		ip_hdr */
		uint16_t checksum = ip_checksum(ip_hdr, sizeof(struct iphdr));


		/* Daca checksum-ul nu este 0, fac drop la pachetul de date */
		if (checksum != 0) {
			continue;
		}

		/* TODO 4: Check TTL >= 1 */

		/* Daca ttl-ul e mai mic ca 1, fac drop la pachetul de date */
		if (ip_hdr->ttl == 0) {
			continue;
		}

		/* TODO 5: Find best matching route (using the function you wrote at TODO 1) */

		/* Gasesc cea mai buna ruta pentru adresa de destinatie a adresei IP */
		struct route_table_entry *bestRoute = get_best_route(ip_hdr->daddr);


		/* Facem drop la pachet daca nu avem o ruta potrivita */
		if (bestRoute == NULL) {

			continue;
		}

		/* TODO 6: Update TTL and recalculate the checksum */

		/* Updatez ttl-ul si checksum-ul */

		ip_hdr->ttl--;

		ip_hdr->check = 0;

		ip_hdr->check = ip_checksum(ip_hdr, sizeof(struct iphdr));


		/* TODO 7: Find matching ARP entry and update Ethernet addresses */

		/* Convertesc adresa ip pt next hop intr-una MAC */
		struct arp_entry *matchARP = get_arp_entry(bestRoute->next_hop);

		/* Updatez adresa Ethernet cu noua adresa MAC gasita */
		memcpy(eth_hdr->ether_dhost, matchARP->mac, sizeof(matchARP->mac));

		/* Obtin interfata potrivita pentru destinatia pachetului, folosind 
		sursa protocolului Ethernet */
		get_interface_mac(bestRoute->interface, eth_hdr->ether_shost);


		/* TODO 8: Forward the pachet to best_route->interface */

		/* Trimit mesajul pe interfata corespunzatoare */
		send_packet(bestRoute->interface, &m);
	}
}

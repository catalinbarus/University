#ifndef TREE_H_D
#define TREE_H_

#include <stdio.h>
#include <stdlib.h>

typedef int Item;

typedef struct Link
  {
    Item  elem;
    struct Link *l;
    struct Link *r;
  } TreeNode;



void Init(TreeNode **t, Item x)
{
   
}

void Insert(TreeNode **t, Item x)
{
  

}

void PrintPostorder(TreeNode *t)
{



}

void PrintPreorder(TreeNode *t)
{


}

void PrintInorder(TreeNode *t)
{

 

}

void Free(TreeNode **t)
{


}

int Size(TreeNode* t)
{


}

int maxDepth(TreeNode *t)
{

}

#endif // LINKEDSTACK_H_INCLUDED
